# PC gaming : panier LDLC livré en Polynésie

Configuration ASUS avec Intel Core Ultra 7 270K Plus et RTX 5060, pour Battlefield 6, Dune: Awakening, ARC Raiders et Once Human. Prix relevés sur ldlc.com le 1er octobre 2026, boîtier non inclus.

## Contenu

| Fichier | À quoi il sert |
|---|---|
| `index.html` | Page interactive : liens vers chaque pièce LDLC, cases à cocher, calcul du coût final avec douane en euros et en XPF. S'ouvre dans n'importe quel navigateur, sans installation. |
| `Panier_PC_Polynesie.xlsx` | Le même panier dans Excel : onglets Panier, Coût final, Options et À savoir. Les cellules en bleu sont modifiables, tout le reste se recalcule. |

## Utilisation

1. Ouvre `index.html` (double-clic) ou le fichier Excel.
2. Ajoute chaque pièce à ton panier LDLC avec les liens fournis.
3. À l'étape paiement, LDLC affiche les frais de port vers la Polynésie : saisis ce montant dans la page ou dans l'onglet « Coût final ».
4. Le coût total arrivé chez toi se met à jour, avec la marge restante sur le budget de 2 500 €.

## Hypothèses du calcul

- LDLC facture les DOM-TOM hors taxe : prix HT = prix TTC ÷ 1,2.
- Douane de Polynésie : droit de douane 10 % (hypothèse prudente), TEAP 2 %, péage 1,25 %, TEEI 1 %, petites taxes fixes environ 6 €, puis TVA polynésienne 16 % sur l'ensemble.
- Frais de dédouanement estimés à 60 €.
- 1 € = 119,332 XPF.

Il s'agit d'une estimation : le montant exact sera celui de la déclaration en douane. Les prix LDLC changent souvent, vérifie-les avant de commander.
